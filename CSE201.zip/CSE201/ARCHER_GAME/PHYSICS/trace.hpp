#ifndef TRACE_HPP_INCLUDED
#define TRACE_HPP_INCLUDED

#include "VECTOR_2D.hpp"
#include "trace_constants.hpp"

#include<bits/stdc++.h>
#include <SFML/Graphics.hpp>

class Trace: public sf::Drawable{
private:
///public:
    double Age;
    double radius;

    Vector2D pos;

    bool isAlive;

    TraceConstants constants;

    ///TO BE CHANGED
    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const
    {
        std::cout << "AHHHHHH" << std::endl;
        sf::CircleShape shape(radius);

        shape.setFillColor(sf::Color(255, 213, 0));


        shape.setPosition(pos.get_x()-radius,target.getSize().y - (pos.get_y() + radius) );
        target.draw(shape);
    }

public:
    Trace(TraceConstants& constants, Vector2D pos);
    void update(double duration);
    bool alive();
};

#endif // TRACE_HPP_INCLUDED
