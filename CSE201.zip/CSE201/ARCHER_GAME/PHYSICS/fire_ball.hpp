#ifndef FIRE_BALL_HPP_INCLUDED
#define FIRE_BALL_HPP_INCLUDED

#include "VECTOR_2D.hpp"
#include<SFML/Graphics.hpp>

class CollisionGenerator;

class FIRE_BALL: public sf::Drawable{
private:
    double MASS;
    double RADIUS;

    Vector2D Pos;
    Vector2D Vel;

    Vector2D ForceTot;

    sf::Color color;

    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const
    {
        sf::CircleShape shape(RADIUS);

        shape.setFillColor(color);


        shape.setPosition(Pos.get_x()-RADIUS,target.getSize().y - (Pos.get_y() + RADIUS) );
        target.draw(shape);
    }

public:

    friend CollisionGenerator;

    FIRE_BALL(double MASS, double RADIUS, Vector2D Pos, Vector2D Vel,sf::Color color);

    double getMass() const;
    double getRadius() const;

    Vector2D getPos() const;
    Vector2D getVel() const;
    void ResetForce();
    void updateForceTot(Vector2D AddForce);
    void update(double duration);
};

#endif // FIRE_BALL_HPP_INCLUDED
