#ifndef PLAYER_BOX_HPP_INCLUDED
#define PLAYER_BOX_HPP_INCLUDED

#include<SFML/Graphics.hpp>
#include<bits/stdc++.h>

class PLayerBox: public sf::Drawable{
public:

    ///feris damateba mere sheidzleba
    ///int readinessToThrow;
    double W;
    double H;

    double pos_x;
    double pos_y;

    double length;

    void move_to_right();
    void move_to_left();

    virtual void draw(sf::RenderTarget& target, sf::RenderStates states) const
    {
        sf::RectangleShape shape(sf::Vector2f(length, length));

        shape.setFillColor(sf::Color(255,0,0));
        shape.setPosition(pos_x - length/2, H - (pos_y + length/2) );

        target.draw(shape);
    }

public:
    PLayerBox(double pos_x, double pos_y, double length,double W,double H);
};

#endif // PLAYER_BOX_HPP_INCLUDED
