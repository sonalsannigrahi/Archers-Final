#include "player_box.hpp"

PLayerBox::PLayerBox(double pos_x, double pos_y, double length, double W, double H)
{
    this->pos_x = pos_x;
    this->pos_y = pos_y;
    this->length = length;

    this->W = W;
    this->H = H;
}


void PLayerBox::move_to_left()
{
    pos_x -= 5.0;
    if(pos_x < length/2){
        pos_x = length/2;
    }
}


void PLayerBox::move_to_right()
{
    pos_x += 5.0;
    if(pos_x > W - length/2){
        pos_x = W - length/2;
    }
}



